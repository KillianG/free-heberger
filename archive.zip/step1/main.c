#include <string.h>
#include <stdlib.h>

int main()
{
	char s1[] = "c";
	char s2[] = "at /ch2/step2 .";
	system(strcat(s1, s2));
}
