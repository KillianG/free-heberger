#include <stdlib.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

char *dl9lm57()
{
	ssize_t ret;
	char *buff;

	if ((buff = malloc(sizeof(*buff) * (50 + 1))) == NULL)
		return (NULL);
	if ((ret = read(0, buff, 50)) > 1) {
		buff[ret - 1] = '\0';
		return (buff);
	}
	buff[0] = '\0';
	return (buff);
}

int My_57Rl3n(char *str)
{
	int i;
	for (i = 0; str[i] != 0; i++)
		;
	return (i);
}

void tH3_3nD()
{
	exit(34567);
}

void _A3b4aj5B9_(char *str)
{
	if (str[5] != 'd')
		__asm__("jmp tH3_3nD");
	if (str[4] != '3')
		__asm__("jmp tH3_3nD");
	if (str[3] != 'G')
		__asm__("jmp tH3_3nD");
	if (str[2] != 'w')
		__asm__("jmp tH3_3nD");
	if (str[1] != 'v')
		__asm__("jmp tH3_3nD");
	if (str[0] != '3')
		__asm__("jmp tH3_3nD");
	char a91120983[35] = "546833204431673137203135202a2a332a";
	printf("%s\n", a91120983);
	__asm__("jmp tH3_3nD");
	char *s = strdup(
		"Lorem ipsum dolor sit amet,"
		"consectetur adipiscing elit. "
		"Etiam dictum, urna eget pellentesque mattis, neque lacus "
		"eleifend diam, ut tempus felis mi ut ex. Morbi semper ac nunc "
		"non porttitor. Mauris convallis augue in libero faucibus, id "
		"cursus sapien laoreet. Morbi tristique purus et bibendum "
		"feugiat. Suspendisse massa augue, consequat non ultricies "
		"eget, mattis interdum lacus. Quisque lobortis ultricies "
		"risus, et sodales leo bibendum non. Phasellus id urna non "
		"lorem consectetur tempus eu id nulla. Quisque ac iaculis "
		"mauris. Mauris vitae mi sed nisi tempor venenatis et non "
		"felis. Pellentesque sapien tortor, ornare ut elementum ut, "
		"interdum nec ipsum.Aenean nibh turpis, bibendum et maximus "
		"sed, consequat at purus. Donec ultrices porta libero, vitae "
		"egestas massa lobortis ac. Praesent varius felis turpis, in "
		"rhoncus sapien, a cursus ex enim sed nunc. Ut at facilisis "
		"nulla, id convallis mauris. Duis ante nulla, dignissim id "
		"diam vel, tristique tincidunt odio. Sed non justo pretium, "
		"pulvinar tellus ac, laoreet justo. Mauris sed pellentesque "
		"lorem. Nunc commodo justo magna, pretium porta magna pretium "
		"rhoncus.Aenean feugiat nec erat ac convallis. Aenean velit "
		"diam, blandit a metus ut, consequat fringilla dui. Curabitur "
		"luctus vulputate mauris ut accumsan. Sed condimentum ac arcu "
		"vel convallis. Ut venenatis egestas tortor, sed egestas purus "
		"rutrum quis. Cras volutpat sem ac varius tristique. Duis "
		"vitae risus nulla. Vivamus et vulputate urna. Sed dui ligula, "
		"malesuada finibus justo in, elementum molestie neque. Nam "
		"laoreet vitae tellus porta dapibus. Mauris eros orci, finibus "
		"a libero vel, consectetur commodo nulla. Donec at porttitor "
		"nulla. Pellentesque interdum turpis non risus ultrices "
		"suscipit vel in orci.");
}

void RYbdaz78l()
{
	char *line;
	printf("Enter password: \n");
	line = dl9lm57();
	if (My_57Rl3n(line) != 6) {
		__asm__("jmp tH3_3nD");
	}
	_A3b4aj5B9_(line);
	char *s = strdup(
		"Lorem ipsum dolor sit amet,"
		"consectetur adipiscing elit. "
		"Etiam dictum, urna eget pellentesque mattis, neque lacus "
		"eleifend diam, ut tempus felis mi ut ex. Morbi semper ac nunc "
		"non porttitor. Mauris convallis augue in libero faucibus, id "
		"cursus sapien laoreet. Morbi tristique purus et bibendum "
		"feugiat. Suspendisse massa augue, consequat non ultricies "
		"eget, mattis interdum lacus. Quisque lobortis ultricies "
		"risus, et sodales leo bibendum non. Phasellus id urna non "
		"lorem consectetur tempus eu id nulla. Quisque ac iaculis "
		"mauris. Mauris vitae mi sed nisi tempor venenatis et non "
		"felis. Pellentesque sapien tortor, ornare ut elementum ut, "
		"interdum nec ipsum.Aenean nibh turpis, bibendum et maximus "
		"sed, consequat at purus. Donec ultrices porta libero, vitae "
		"egestas massa lobortis ac. Praesent varius felis turpis, in "
		"rhoncus sapien, a cursus ex enim sed nunc. Ut at facilisis "
		"nulla, id convallis mauris. Duis ante nulla, dignissim id "
		"diam vel, tristique tincidunt odio. Sed non justo pretium, "
		"pulvinar tellus ac, laoreet justo. Mauris sed pellentesque "
		"lorem. Nunc commodo justo magna, pretium porta magna pretium "
		"rhoncus.Aenean feugiat nec erat ac convallis. Aenean velit "
		"diam, blandit a metus ut, consequat fringilla dui. Curabitur "
		"luctus vulputate mauris ut accumsan. Sed condimentum ac arcu "
		"vel convallis. Ut venenatis egestas tortor, sed egestas purus "
		"rutrum quis. Cras volutpat sem ac varius tristique. Duis "
		"vitae risus nulla. Vivamus et vulputate urna. Sed dui ligula, "
		"malesuada finibus justo in, elementum molestie neque. Nam "
		"laoreet vitae tellus porta dapibus. Mauris eros orci, finibus "
		"a libero vel, consectetur commodo nulla. Donec at porttitor "
		"nulla. Pellentesque interdum turpis non risus ultrices "
		"suscipit vel in orci.");
}


void a15b48dfG()
{
	if (ptrace(PTRACE_TRACEME, 0, 1, 0) < 0) {
		printf("/!\\ DEBUGGER DETECTED /!\\\n");
		exit(84);
	} else
		ptrace(PTRACE_DETACH, 0, 1, 0);
	RYbdaz78l();
}

int main()
{
	char *s = strdup(
		"Lorem ipsum dolor sit amet,"
		"consectetur adipiscing elit. "
		"Etiam dictum, urna eget pellentesque mattis, neque lacus "
		"eleifend diam, ut tempus felis mi ut ex. Morbi semper ac nunc "
		"non porttitor. Mauris convallis augue in libero faucibus, id "
		"cursus sapien laoreet. Morbi tristique purus et bibendum "
		"feugiat. Suspendisse massa augue, consequat non ultricies "
		"eget, mattis interdum lacus. Quisque lobortis ultricies "
		"risus, et sodales leo bibendum non. Phasellus id urna non "
		"lorem consectetur tempus eu id nulla. Quisque ac iaculis "
		"mauris. Mauris vitae mi sed nisi tempor venenatis et non "
		"felis. Pellentesque sapien tortor, ornare ut elementum ut, "
		"interdum nec ipsum.Aenean nibh turpis, bibendum et maximus "
		"sed, consequat at purus. Donec ultrices porta libero, vitae "
		"egestas massa lobortis ac. Praesent varius felis turpis, in "
		"rhoncus sapien, a cursus ex enim sed nunc. Ut at facilisis "
		"nulla, id convallis mauris. Duis ante nulla, dignissim id "
		"diam vel, tristique tincidunt odio. Sed non justo pretium, "
		"pulvinar tellus ac, laoreet justo. Mauris sed pellentesque "
		"lorem. Nunc commodo justo magna, pretium porta magna pretium "
		"rhoncus.Aenean feugiat nec erat ac convallis. Aenean velit "
		"diam, blandit a metus ut, consequat fringilla dui. Curabitur "
		"luctus vulputate mauris ut accumsan. Sed condimentum ac arcu "
		"vel convallis. Ut venenatis egestas tortor, sed egestas purus "
		"rutrum quis. Cras volutpat sem ac varius tristique. Duis "
		"vitae risus nulla. Vivamus et vulputate urna. Sed dui ligula, "
		"malesuada finibus justo in, elementum molestie neque. Nam "
		"laoreet vitae tellus porta dapibus. Mauris eros orci, finibus "
		"a libero vel, consectetur commodo nulla. Donec at porttitor "
		"nulla. Pellentesque interdum turpis non risus ultrices "
		"suscipit vel in orci.");
	a15b48dfG();
	return (0);
}
